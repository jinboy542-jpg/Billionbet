import React, {useMemo, useState} from "react";
import {createRoot} from "react-dom/client";
import {
  Trophy, Wallet, UserRound, Menu, X, ChevronRight, Search, ShieldCheck,
  Clock3, Star, Ticket, Home, CircleDollarSign, Settings, Users,
  BarChart3, LogOut, Bell, LockKeyhole, Smartphone, HelpCircle
} from "lucide-react";
import "./styles.css";

const matches = [
  {id:1, league:"Premier League", time:"18:00", home:"Arsenal", away:"Chelsea", date:"Today", odds:{home:"1.78", draw:"3.65", away:"4.55"}},
  {id:2, league:"Premier League", time:"20:30", home:"Liverpool", away:"Manchester City", date:"Today", odds:{home:"2.10", draw:"3.40", away:"3.10"}},
  {id:3, league:"La Liga", time:"21:00", home:"Barcelona", away:"Atletico Madrid", date:"Today", odds:{home:"1.85", draw:"3.55", away:"4.10"}},
  {id:4, league:"Serie A", time:"21:45", home:"Inter", away:"AC Milan", date:"Tomorrow", odds:{home:"1.92", draw:"3.35", away:"3.90"}},
  {id:5, league:"Champions League", time:"22:00", home:"Real Madrid", away:"Bayern Munich", date:"Tomorrow", odds:{home:"2.02", draw:"3.70", away:"3.20"}},
  {id:6, league:"Ligue 1", time:"19:00", home:"PSG", away:"Monaco", date:"Tomorrow", odds:{home:"1.65", draw:"4.20", away:"4.80"}}
];

const sports = ["Football","Basketball","Tennis","Rugby","Volleyball","Esports"];

function App(){
  const [page,setPage] = useState("home");
  const [mobileOpen,setMobileOpen] = useState(false);
  const [slip,setSlip] = useState([]);
  const [balance,setBalance] = useState(0);
  const [auth,setAuth] = useState(null);
  const [admin,setAdmin] = useState(false);
  const [search,setSearch] = useState("");

  const filtered = useMemo(()=>matches.filter(m=>
    `${m.home} ${m.away} ${m.league}`.toLowerCase().includes(search.toLowerCase())
  ),[search]);

  function addPick(match, market, odd){
    const key = `${match.id}-${market}`;
    setSlip(s => s.some(x=>x.key===key) ? s.filter(x=>x.key!==key) :
      [...s.filter(x=>x.matchId!==match.id), {key,matchId:match.id, event:`${match.home} vs ${match.away}`, market, odd:Number(odd)}]
    );
  }
  function removePick(key){setSlip(s=>s.filter(x=>x.key!==key));}

  return <div className="app">
    <header className="topbar">
      <div className="brand" onClick={()=>setPage("home")}><span className="brandMark">J</span><span>Jin<span>Bet</span></span></div>
      <div className="desktopNav">
        {["home","sports","live","promos"].map(p=><button className={page===p?"nav active":"nav"} onClick={()=>setPage(p)} key={p}>{p[0].toUpperCase()+p.slice(1)}</button>)}
      </div>
      <div className="headerActions">
        <button className="iconBtn" title="Search"><Search size={19}/></button>
        <button className="walletMini" onClick={()=>setPage("wallet")}><Wallet size={17}/><b>KES {balance.toLocaleString()}</b></button>
        <button className="loginBtn" onClick={()=>setAuth("login")}><UserRound size={17}/> Login</button>
        <button className="registerBtn" onClick={()=>setAuth("register")}>Register</button>
        <button className="mobileMenu" onClick={()=>setMobileOpen(true)}><Menu/></button>
      </div>
    </header>

    {mobileOpen && <div className="mobileDrawer">
      <button className="closeDrawer" onClick={()=>setMobileOpen(false)}><X/></button>
      <div className="drawerBrand">JinBet</div>
      {["home","sports","live","promos","wallet","bets"].map(p=><button key={p} onClick={()=>{setPage(p);setMobileOpen(false)}}>{p.toUpperCase()}</button>)}
      <button className="drawerLogin" onClick={()=>{setAuth("login");setMobileOpen(false)}}>LOGIN / REGISTER</button>
    </div>}

    <main>
      {page==="home" && <Home setPage={setPage} setAuth={setAuth} />}
      {page==="sports" && <Sports matches={filtered} search={search} setSearch={setSearch} addPick={addPick} slip={slip}/>}
      {page==="live" && <Sports matches={filtered.slice(0,3)} search={search} setSearch={setSearch} addPick={addPick} slip={slip} live/>}
      {page==="promos" && <Promos/>}
      {page==="wallet" && <WalletPage balance={balance} setBalance={setBalance} setAuth={setAuth}/>}
      {page==="bets" && <MyBets/>}
      {page==="admin" && <Admin/>}
    </main>

    <BetSlip slip={slip} removePick={removePick} setSlip={setSlip} balance={balance} setAuth={setAuth}/>
    <footer>
      <div className="footerTop">
        <div><div className="footerLogo">JinBet</div><p>Predict. Compete. Enjoy.</p></div>
        <div><b>Company</b><button>About</button><button>Careers</button><button>Contact</button></div>
        <div><b>Help</b><button>Responsible betting</button><button>Terms & Conditions</button><button>Privacy</button></div>
        <div><b>Security</b><p><ShieldCheck size={16}/> Secure account protection</p><p><LockKeyhole size={16}/> KYC & age verification</p></div>
      </div>
      <div className="footerBottom">© 2026 JinBet. Demo platform — real-money betting requires applicable licensing and regulated integrations.</div>
    </footer>

    {auth && <AuthModal mode={auth} close={()=>setAuth(null)} onSuccess={()=>setAuth(null)}/>}
  </div>
}

function Home({setPage,setAuth}){
 return <div>
  <section className="hero">
    <div className="heroCopy">
      <div className="pill"><Star size={15}/> KENYA SPORTS PLATFORM</div>
      <h1>BET SMART.<br/><span>WIN BIG.</span></h1>
      <p>One modern place for football, live sports, promotions and your complete betting wallet.</p>
      <div className="heroButtons"><button className="primary" onClick={()=>setPage("sports")}>Start Betting <ChevronRight/></button><button className="secondary" onClick={()=>setAuth("register")}>Create Account</button></div>
      <div className="trustRow"><span><ShieldCheck/> Secure</span><span><Smartphone/> Mobile ready</span><span><Clock3/> 24/7</span></div>
    </div>
    <div className="heroCard">
      <div className="heroCardHead"><span>TOP EVENT</span><span className="liveDot">● LIVE</span></div>
      <div className="heroTeams"><div><div className="teamIcon">A</div><b>Arsenal</b></div><strong>VS</strong><div><div className="teamIcon">C</div><b>Chelsea</b></div></div>
      <div className="heroOdds"><span>1 <b>1.78</b></span><span>X <b>3.65</b></span><span>2 <b>4.55</b></span></div>
      <button className="cardAction" onClick={()=>setPage("sports")}>View markets <ChevronRight/></button>
    </div>
  </section>

  <section className="section">
    <div className="sectionTitle"><div><small>EXPLORE</small><h2>Popular Sports</h2></div><button onClick={()=>setPage("sports")}>View all <ChevronRight/></button></div>
    <div className="sportGrid">{sports.map((s,i)=><button className="sportCard" onClick={()=>setPage("sports")} key={s}><span>{["⚽","🏀","🎾","🏉","🏐","🎮"][i]}</span><b>{s}</b><small>{i===0?"120+ events":"40+ events"}</small></button>)}</div>
  </section>

  <section className="section">
    <div className="sectionTitle"><div><small>FEATURED</small><h2>Today's Matches</h2></div><button onClick={()=>setPage("sports")}>All matches <ChevronRight/></button></div>
    <div className="matchList">{matches.slice(0,4).map(m=><MatchCard key={m.id} m={m} addPick={()=>{}}/>)}</div>
  </section>

  <section className="features">
    <div><ShieldCheck/><h3>Protected</h3><p>Account and transaction security designed for a regulated platform.</p></div>
    <div><Wallet/><h3>Easy Wallet</h3><p>Clear wallet structure for deposits, withdrawals and transaction history.</p></div>
    <div><Trophy/><h3>More Markets</h3><p>Sports, competitions and betting markets can be managed centrally.</p></div>
  </section>
 </div>
}

function Sports({matches,search,setSearch,addPick,slip,live=false}){
 return <section className="page">
  <div className="pageHead"><div><small>{live?"LIVE SPORTS":"SPORTSBOOK"}</small><h1>{live?"Live Now":"Sports & Markets"}</h1></div><div className="search"><Search size={18}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search teams or leagues"/></div></div>
  <div className="sportTabs">{sports.map(s=><button key={s} className={s==="Football"?"selected":""}>{s}</button>)}</div>
  <div className="matchList">{matches.map(m=><MatchCard key={m.id} m={m} addPick={addPick} selected={slip}/>)}</div>
 </section>
}

function MatchCard({m,addPick,selected=[]}){
 const pick=(market,odd)=>addPick(m,market,odd);
 return <article className="matchCard">
   <div className="matchMeta"><span>{m.league}</span><span>{m.date} • {m.time}</span></div>
   <div className="matchMain"><div className="teams"><b>{m.home}</b><span>vs</span><b>{m.away}</b></div><div className="marketLabel">1X2</div>
   <div className="odds"><button className={selected.some(x=>x.key===`${m.id}-1`)? "odd selected": "odd"} onClick={()=>pick("1",m.odds.home)}><small>1</small>{m.odds.home}</button>
   <button className={selected.some(x=>x.key===`${m.id}-X`)? "odd selected": "odd"} onClick={()=>pick("X",m.odds.draw)}><small>X</small>{m.odds.draw}</button>
   <button className={selected.some(x=>x.key===`${m.id}-2`)? "odd selected": "odd"} onClick={()=>pick("2",m.odds.away)}><small>2</small>{m.odds.away}</button></div>
   </div>
 </article>
}

function BetSlip({slip,removePick,setSlip,balance,setAuth}){
 const [stake,setStake]=useState("");
 const total=slip.reduce((a,x)=>a*x.odd,1);
 const potential=(Number(stake||0)*total).toFixed(2);
 return <aside className="betslip">
   <div className="slipHead"><span><Ticket/> Bet Slip <b>{slip.length}</b></span><button onClick={()=>setSlip([])}>Clear</button></div>
   {slip.length===0?<div className="emptySlip"><Ticket size={34}/><b>Your bet slip is empty</b><p>Select odds from a match to add a bet.</p></div>:
   <><div className="slipItems">{slip.map(x=><div className="slipItem" key={x.key}><button onClick={()=>removePick(x.key)}><X size={13}/></button><div><b>{x.event}</b><small>Market {x.market} • Odds {x.odd}</small></div></div>)}</div>
   <div className="slipCalc"><div><span>Total odds</span><b>{total.toFixed(2)}</b></div><label>Stake (KES)<input type="number" min="0" value={stake} onChange={e=>setStake(e.target.value)} placeholder="0"/></label><div><span>Potential return</span><b>KES {potential}</b></div>
   <button className="primary full" onClick={()=>{if(!stake)return alert("Enter a stake."); if(balance<Number(stake))return setAuth("login"); alert("Demo bet only. Connect a licensed backend, wallet and settlement service before real-money use.")}}>Place Bet</button></div></>}
 </aside>
}

function Promos(){return <section className="page"><div className="pageHead"><div><small>JINBET</small><h1>Promotions</h1></div></div><div className="promoGrid">
 {["Welcome Offer","Weekend Boost","Free Bet Friday","Accumulator Bonus"].map((x,i)=><div className="promo" key={x}><span>OFFER {i+1}</span><h2>{x}</h2><p>Promotional campaign area ready for your approved bonus rules, eligibility and terms.</p><button>View details</button></div>)}</div></section>}

function WalletPage({balance,setBalance,setAuth}){
 return <section className="page"><div className="pageHead"><div><small>ACCOUNT</small><h1>Wallet</h1></div></div>
 <div className="walletHero"><div><small>AVAILABLE BALANCE</small><strong>KES {balance.toLocaleString()}</strong><p>Demo wallet • not connected to real payments</p></div><Wallet size={52}/></div>
 <div className="walletActions"><button onClick={()=>setBalance(balance+500)} className="primary">+ Deposit Demo KES 500</button><button onClick={()=>alert("Demo withdrawal only.")}>Withdraw</button><button onClick={()=>setAuth("login")}>Transaction history</button></div>
 <div className="notice"><ShieldCheck/><div><b>Production wallet architecture</b><p>Use a server-side ledger, reconciliation, KYC, payment provider and audit trail before enabling real deposits or withdrawals.</p></div></div>
 </section>
}

function MyBets(){return <section className="page"><div className="pageHead"><div><small>ACCOUNT</small><h1>My Bets</h1></div></div><div className="emptyPanel"><Ticket size={42}/><h2>No bets yet</h2><p>Your placed bets will appear here.</p></div></section>}

function Admin(){return <section className="page admin"><div className="pageHead"><div><small>CEO / ADMIN</small><h1>JinBet Control Center</h1></div><button className="secondary"><Settings/> Settings</button></div>
 <div className="stats"><div><Users/><span>Registered users</span><b>0</b></div><div><BarChart3/><span>Bets today</span><b>0</b></div><div><CircleDollarSign/><span>Turnover</span><b>KES 0</b></div><div><ShieldCheck/><span>Compliance alerts</span><b>0</b></div></div>
 <div className="adminGrid"><div className="adminCard"><h3>Operations</h3>{["Users & KYC","Bets & settlements","Wallet transactions","Sports & odds","Promotions"].map(x=><button key={x}>{x}<ChevronRight/></button>)}</div><div className="adminCard"><h3>Compliance</h3>{["Age verification","Responsible gambling","AML / fraud monitoring","Audit logs","Reports"].map(x=><button key={x}>{x}<ChevronRight/></button>)}</div></div>
 <div className="notice"><LockKeyhole/><div><b>Administrator security</b><p>Use role-based access, MFA, server-side authorization and immutable audit logs. Never put admin secrets in VITE_ environment variables.</p></div></div>
 </section>}

function AuthModal({mode,close,onSuccess}){const [register,setRegister]=useState(mode==="register");return <div className="modalBg"><div className="modal"><button className="modalClose" onClick={close}><X/></button><div className="modalLogo">J</div><h2>{register?"Create your JinBet account":"Welcome back"}</h2><p>{register?"Join the platform to manage your account and bets.":"Sign in to continue."}</p>{register&&<input placeholder="Full name"/>}<input placeholder="Phone number or email"/><input placeholder="Password" type="password"/>{register&&<label className="check"><input type="checkbox"/> I confirm I am of legal betting age.</label>}<button className="primary full" onClick={()=>{alert("Demo authentication only. Connect a secure backend before production.");onSuccess()}}>{register?"Create Account":"Sign In"}</button><button className="linkBtn" onClick={()=>setRegister(!register)}>{register?"Already have an account? Sign in":"New to JinBet? Create account"}</button></div></div>}
createRoot(document.getElementById("root")).render(<App/>);