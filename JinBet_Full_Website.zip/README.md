# JinBet — Full Betting Website Starter

A polished Vite + React sportsbook frontend for the JinBet brand.

## Included
- Responsive homepage
- Sportsbook and football markets
- Live sports view
- Bet slip with odds, stake and potential return calculation
- Wallet structure
- Login / registration UI
- My Bets page
- Promotions page
- CEO/Admin control center UI
- Mobile navigation
- Security/compliance UI sections
- Vercel configuration with SPA rewrite to prevent common 404s

## Run locally
npm install
npm run dev

## Production build
npm run build

## Vercel
Framework: Vite
Build command: npm run build
Output directory: dist

The included vercel.json rewrites routes to index.html so the SPA does not show a Vercel 404 on navigation.

## Important
This package is a frontend/product starter. The wallet, authentication, bet placement, deposits, withdrawals, odds feed and admin actions are demo UI and are NOT connected to real money.

Before accepting real-money wagers, add a legally compliant backend, licensed gambling operation, KYC/age verification, responsible-gambling controls, payment provider, odds/data provider, secure wallet ledger, bet settlement engine, fraud/AML controls, audit logging and required regulatory approvals.

Never place private API keys, payment secrets or admin credentials in VITE_* variables.
